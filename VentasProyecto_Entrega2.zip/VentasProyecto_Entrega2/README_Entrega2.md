# Entrega 2 - Semana 5

Se agrega la clase `co.poli.ventas.procesador.main` (segunda clase con metodo `main`).

## Como ejecutar
1. Copiar `main.java` a `src/co/poli/ventas/procesador/` del proyecto de Eclipse.
2. Ejecutar `GenerateInfoFiles` (genera la carpeta `datos/`).
3. Ejecutar `main` (genera la carpeta `reportes/`):
   - `reporte_vendedores.csv`
   - `reporte_productos.csv`
   - `reporte_errores.txt`

## Extras implementados
- a. Mas de un archivo por vendedor.
- c. Deteccion de formato erroneo / informacion incoherente.

Ver `FALTANTES.txt` para lo pendiente.
