package co.poli.ventas.modelo;

import java.util.Locale;

/**
 * Representa un producto disponible para la venta.
 *
 * @author Grupo XX
 * @version 1.0
 */
public class Producto {

    /** Identificador unico del producto. */
    private final String id;

    /** Nombre del producto. */
    private final String nombre;

    /** Precio por unidad del producto. */
    private final double precioPorUnidad;

    /**
     * Crea un producto.
     *
     * @param id              identificador unico
     * @param nombre          nombre del producto
     * @param precioPorUnidad precio por unidad
     */
    public Producto(String id, String nombre, double precioPorUnidad) {
        this.id = id;
        this.nombre = nombre;
        this.precioPorUnidad = precioPorUnidad;
    }

    /**
     * Obtiene el identificador.
     *
     * @return identificador del producto
     */
    public String getId() {
        return id;
    }

    /**
     * Obtiene el nombre.
     *
     * @return nombre del producto
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el precio.
     *
     * @return precio por unidad
     */
    public double getPrecioPorUnidad() {
        return precioPorUnidad;
    }

    /**
     * Devuelve la linea del archivo de productos: {@code ID;Nombre;Precio}.
     *
     * @return linea en formato CSV con punto y coma
     */
    public String aLineaArchivo() {
        return id + ";" + nombre + ";" + String.format(Locale.US, "%.2f", precioPorUnidad);
    }
}
