package co.poli.ventas.modelo;

/**
 * Representa a un vendedor de la empresa.
 *
 * @author Grupo XX
 * @version 1.0
 */
public class Vendedor {

    /** Tipo de documento (por ejemplo CC, CE, TI). */
    private final String tipoDocumento;

    /** Numero de documento. */
    private final long numeroDocumento;

    /** Nombres del vendedor. */
    private final String nombres;

    /** Apellidos del vendedor. */
    private final String apellidos;

    /**
     * Crea un vendedor.
     *
     * @param tipoDocumento   tipo de documento
     * @param numeroDocumento numero de documento
     * @param nombres         nombres
     * @param apellidos       apellidos
     */
    public Vendedor(String tipoDocumento, long numeroDocumento, String nombres, String apellidos) {
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.nombres = nombres;
        this.apellidos = apellidos;
    }

    /**
     * Obtiene el tipo de documento.
     *
     * @return tipo de documento
     */
    public String getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * Obtiene el numero de documento.
     *
     * @return numero de documento
     */
    public long getNumeroDocumento() {
        return numeroDocumento;
    }

    /**
     * Obtiene los nombres.
     *
     * @return nombres
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * Obtiene los apellidos.
     *
     * @return apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Devuelve la linea del archivo de vendedores:
     * {@code Tipo;Numero;Nombres;Apellidos}.
     *
     * @return linea en formato CSV con punto y coma
     */
    public String aLineaArchivo() {
        return tipoDocumento + ";" + numeroDocumento + ";" + nombres + ";" + apellidos;
    }
}
