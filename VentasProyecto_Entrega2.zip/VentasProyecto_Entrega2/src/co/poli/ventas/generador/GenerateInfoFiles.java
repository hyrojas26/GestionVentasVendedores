package co.poli.ventas.generador;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import co.poli.ventas.modelo.Producto;
import co.poli.ventas.modelo.Vendedor;

/**
 * Primera clase con metodo {@code main} del proyecto. Genera los archivos
 * planos pseudoaleatorios que sirven de entrada a la clase
 * {@code co.poli.ventas.procesador.main}. Los archivos se crean en la carpeta
 * {@code datos/}:
 * <ul>
 * <li>{@code vendedores.txt}: {@code Tipo;Numero;Nombres;Apellidos}</li>
 * <li>{@code productos.txt}: {@code ID;Nombre;PrecioPorUnidad}</li>
 * <li>{@code ventas_vendedor_<id>.txt}: encabezado {@code Tipo;Numero} y una
 * venta por linea ({@code IDProducto;Cantidad;})</li>
 * </ul>
 * El programa no solicita informacion al usuario.
 *
 * @author Grupo XX
 * @version 1.0
 */
public class GenerateInfoFiles {

    /** Carpeta de salida. */
    private static final String CARPETA_DATOS = "datos";

    /** Cantidad de productos que se generan por defecto. */
    private static final int CANTIDAD_PRODUCTOS = 10;

    /** Cantidad de vendedores que se generan por defecto. */
    private static final int CANTIDAD_VENDEDORES = 8;

    /** Cantidad de ventas por vendedor que se generan por defecto. */
    private static final int VENTAS_POR_VENDEDOR = 15;

    /** Cantidad maxima de unidades por venta. */
    private static final int CANTIDAD_MAXIMA_POR_VENTA = 20;

    /** Tipo de documento usado cuando no se indica uno. */
    private static final String TIPO_POR_DEFECTO = "CC";

    /** Nombres de personas reales para generar vendedores coherentes. */
    private static final String[] NOMBRES = { "Juan Carlos", "Maria Fernanda", "Andres Felipe",
        "Laura Sofia", "Camilo Andres", "Paula Andrea", "Sebastian", "Valentina", "Diego Alejandro",
        "Daniela", "Santiago", "Carolina", "Nicolas", "Natalia", "Miguel Angel", "Juliana" };

    /** Apellidos de personas reales para generar vendedores coherentes. */
    private static final String[] APELLIDOS = { "Garcia Lopez", "Rodriguez Martinez", "Gomez Perez",
        "Hernandez Diaz", "Ramirez Torres", "Sanchez Vargas", "Castro Rojas", "Mora Jimenez",
        "Ortiz Silva", "Moreno Cardenas", "Gutierrez Pardo", "Rincon Suarez" };

    /** Tipos de documento posibles. */
    private static final String[] TIPOS_DOCUMENTO = { "CC", "CE", "TI" };

    /** Nombres base de productos. */
    private static final String[] NOMBRES_PRODUCTO = { "Laptop", "Mouse", "Teclado", "Monitor",
        "Impresora", "Auriculares", "Camara Web", "Disco Duro", "Memoria USB", "Parlante",
        "Tablet", "Cargador", "Router", "Microfono", "Silla Ergonomica" };

    /** Generador pseudoaleatorio compartido. */
    private static final Random ALEATORIO = new Random();

    /** Ids de los productos generados; las ventas solo usan estos ids. */
    private static final List<String> IDS_PRODUCTOS = new ArrayList<String>();

    /**
     * Punto de entrada: genera todos los archivos de prueba.
     *
     * @param args argumentos (no se utilizan)
     */
    public static void main(String[] args) {
        try {
            Files.createDirectories(Paths.get(CARPETA_DATOS));
            createProductsFile(CANTIDAD_PRODUCTOS);
            List<Vendedor> vendedores = createSalesManInfoFile(CANTIDAD_VENDEDORES);
            for (Vendedor vendedor : vendedores) {
                createSalesMenFile(VENTAS_POR_VENDEDOR,
                        vendedor.getNombres() + " " + vendedor.getApellidos(),
                        vendedor.getNumeroDocumento(), vendedor.getTipoDocumento());
            }
            System.out.println("Archivos generados con exito en la carpeta '" + CARPETA_DATOS + "'.");
        } catch (IOException e) {
            System.err.println("ERROR: no fue posible generar los archivos. " + e.getMessage());
        }
    }

    /**
     * Crea el archivo pseudoaleatorio de ventas de un vendedor.
     *
     * @param randomSalesCount cantidad de ventas (lineas) a generar
     * @param name             nombre del vendedor
     * @param id               numero de documento del vendedor
     * @throws IOException si no se puede escribir el archivo
     */
    public static void createSalesMenFile(int randomSalesCount, String name, long id)
            throws IOException {
        createSalesMenFile(randomSalesCount, name, id, TIPO_POR_DEFECTO);
    }

    /**
     * Version de {@link #createSalesMenFile(int, String, long)} que permite
     * indicar el tipo de documento del vendedor para el encabezado.
     *
     * @param randomSalesCount cantidad de ventas a generar
     * @param name             nombre del vendedor
     * @param id               numero de documento
     * @param tipoDocumento    tipo de documento (CC, CE, TI)
     * @throws IOException si no se puede escribir el archivo
     */
    public static void createSalesMenFile(int randomSalesCount, String name, long id,
            String tipoDocumento) throws IOException {
        if (IDS_PRODUCTOS.isEmpty()) {
            throw new IOException("Primero se debe crear el archivo de productos.");
        }
        Files.createDirectories(Paths.get(CARPETA_DATOS));
        List<String> lineas = new ArrayList<String>();
        lineas.add(tipoDocumento + ";" + id);
        for (int i = 0; i < randomSalesCount; i++) {
            String idProducto = IDS_PRODUCTOS.get(ALEATORIO.nextInt(IDS_PRODUCTOS.size()));
            int cantidad = 1 + ALEATORIO.nextInt(CANTIDAD_MAXIMA_POR_VENTA);
            lineas.add(idProducto + ";" + cantidad + ";");
        }
        Path ruta = Paths.get(CARPETA_DATOS, "ventas_vendedor_" + id + ".txt");
        Files.write(ruta, lineas, StandardCharsets.UTF_8);
    }

    /**
     * Crea el archivo de productos con id, nombre y precio por unidad.
     *
     * @param productsCount cantidad de productos a generar
     * @return lista de productos generados
     * @throws IOException si no se puede escribir el archivo
     */
    public static List<Producto> createProductsFile(int productsCount) throws IOException {
        Files.createDirectories(Paths.get(CARPETA_DATOS));
        IDS_PRODUCTOS.clear();
        List<Producto> productos = new ArrayList<Producto>();
        List<String> lineas = new ArrayList<String>();
        for (int i = 1; i <= productsCount; i++) {
            String idProducto = String.format("P%03d", i);
            String nombre = NOMBRES_PRODUCTO[(i - 1) % NOMBRES_PRODUCTO.length]
                    + (i > NOMBRES_PRODUCTO.length ? " " + i : "");
            double precio = 5000 + ALEATORIO.nextInt(300) * 1000;
            Producto producto = new Producto(idProducto, nombre, precio);
            productos.add(producto);
            IDS_PRODUCTOS.add(idProducto);
            lineas.add(producto.aLineaArchivo());
        }
        Files.write(Paths.get(CARPETA_DATOS, "productos.txt"), lineas, StandardCharsets.UTF_8);
        return productos;
    }

    /**
     * Crea el archivo de vendedores con nombres y apellidos tomados de listas
     * de nombres reales y documentos unicos.
     *
     * @param salesmanCount cantidad de vendedores a generar
     * @return lista de vendedores generados
     * @throws IOException si no se puede escribir el archivo
     */
    public static List<Vendedor> createSalesManInfoFile(int salesmanCount) throws IOException {
        Files.createDirectories(Paths.get(CARPETA_DATOS));
        List<Vendedor> vendedores = new ArrayList<Vendedor>();
        List<String> lineas = new ArrayList<String>();
        for (int i = 0; i < salesmanCount; i++) {
            String tipo = TIPOS_DOCUMENTO[ALEATORIO.nextInt(TIPOS_DOCUMENTO.length)];
            long numero = 10000000L + i * 1000003L + ALEATORIO.nextInt(1000);
            String nombres = NOMBRES[ALEATORIO.nextInt(NOMBRES.length)];
            String apellidos = APELLIDOS[ALEATORIO.nextInt(APELLIDOS.length)];
            Vendedor vendedor = new Vendedor(tipo, numero, nombres, apellidos);
            vendedores.add(vendedor);
            lineas.add(vendedor.aLineaArchivo());
        }
        Files.write(Paths.get(CARPETA_DATOS, "vendedores.txt"), lineas, StandardCharsets.UTF_8);
        return vendedores;
    }
}
