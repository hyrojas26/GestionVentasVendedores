package co.poli.ventas.procesador;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Segunda clase con metodo {@code main} del proyecto (Entrega 2).
 * <p>
 * Lee los archivos planos producidos por
 * {@code co.poli.ventas.generador.GenerateInfoFiles} (carpeta {@code datos/})
 * y genera dentro de la carpeta {@code reportes/}:
 * </p>
 * <ul>
 * <li>{@code reporte_vendedores.csv}: {@code Nombre;DineroRecaudado}, ordenado
 * de mayor a menor recaudo.</li>
 * <li>{@code reporte_productos.csv}: {@code NombreProducto;Precio}, ordenado de
 * mayor a menor cantidad vendida.</li>
 * <li>{@code reporte_errores.txt}: detalle de las lineas o archivos
 * descartados por formato erroneo o informacion incoherente.</li>
 * </ul>
 * <p>
 * Elementos extra implementados:
 * </p>
 * <ul>
 * <li><b>a.</b> Se procesa mas de un archivo por vendedor: las ventas de todos
 * los archivos cuyo encabezado apunte al mismo documento se acumulan.</li>
 * <li><b>c.</b> Se detectan archivos con formato erroneo o datos incoherentes
 * (producto inexistente, cantidades o precios negativos, vendedor
 * desconocido, lineas mal formadas).</li>
 * </ul>
 * <p>
 * El programa no solicita informacion al usuario. Nota: el nombre de la clase
 * ({@code main}) es el exigido por el enunciado.
 * </p>
 *
 * @author Grupo XX
 * @version 1.0
 */
public class main {

    /** Carpeta de entrada con los archivos generados en la Entrega 1. */
    private static final String CARPETA_DATOS = "datos";

    /** Carpeta donde se escriben los reportes. */
    private static final String CARPETA_REPORTES = "reportes";

    /** Nombre del archivo de vendedores. */
    private static final String ARCHIVO_VENDEDORES = "vendedores.txt";

    /** Nombre del archivo de productos. */
    private static final String ARCHIVO_PRODUCTOS = "productos.txt";

    /** Prefijo de los archivos de ventas por vendedor. */
    private static final String PREFIJO_VENTAS = "ventas_";

    /** Separador de campos en todos los archivos. */
    private static final String SEPARADOR = ";";

    /** Datos de un producto y su cantidad total vendida. */
    private static class InfoProducto {
        private final String nombre;
        private final BigDecimal precioPorUnidad;
        private long cantidadVendida;

        InfoProducto(String id, String nombre, BigDecimal precioPorUnidad) {
            this.nombre = nombre;
            this.precioPorUnidad = precioPorUnidad;
            this.cantidadVendida = 0;
        }
    }

    /** Datos de un vendedor y el dinero total que recaudo. */
    private static class InfoVendedor {
        private final String nombreCompleto;
        private BigDecimal totalRecaudado;

        InfoVendedor(String nombreCompleto) {
            this.nombreCompleto = nombreCompleto;
            this.totalRecaudado = BigDecimal.ZERO;
        }
    }

    /**
     * Punto de entrada. Ejecuta el proceso completo e informa si termino bien
     * o si ocurrio un error. No solicita datos al usuario.
     *
     * @param args argumentos de linea de comandos (no se utilizan)
     */
    public static void main(String[] args) {
        try {
            int cantidadErrores = ejecutar();
            System.out.println("Proceso finalizado con exito. Reportes generados en la carpeta '"
                    + CARPETA_REPORTES + "'.");
            if (cantidadErrores > 0) {
                System.out.println("Aviso: se descartaron " + cantidadErrores
                        + " registros invalidos. Ver " + CARPETA_REPORTES + "/reporte_errores.txt");
            }
        } catch (Exception e) {
            System.err.println("ERROR: no fue posible completar el proceso. " + e.getMessage());
        }
    }

    /**
     * Orquesta la lectura de archivos, el calculo y la escritura de reportes.
     *
     * @return cantidad de registros descartados por ser invalidos
     * @throws IOException si falla la lectura o escritura de archivos
     */
    private static int ejecutar() throws IOException {
        Path carpetaDatos = Paths.get(CARPETA_DATOS);
        if (!Files.isDirectory(carpetaDatos)) {
            throw new IOException("No existe la carpeta '" + CARPETA_DATOS
                    + "'. Ejecute primero GenerateInfoFiles.");
        }
        Path carpetaReportes = Paths.get(CARPETA_REPORTES);
        Files.createDirectories(carpetaReportes);

        List<String> errores = new ArrayList<String>();
        Map<String, InfoProducto> productos = cargarProductos(
                carpetaDatos.resolve(ARCHIVO_PRODUCTOS), errores);
        Map<String, InfoVendedor> vendedores = cargarVendedores(
                carpetaDatos.resolve(ARCHIVO_VENDEDORES), errores);

        int archivosProcesados = procesarVentas(carpetaDatos, productos, vendedores, errores);
        if (archivosProcesados == 0) {
            throw new IOException("No se encontraron archivos de ventas ('" + PREFIJO_VENTAS
                    + "*.txt') en la carpeta '" + CARPETA_DATOS + "'.");
        }

        escribirReporteVendedores(carpetaReportes.resolve("reporte_vendedores.csv"), vendedores);
        escribirReporteProductos(carpetaReportes.resolve("reporte_productos.csv"), productos);
        escribirErrores(carpetaReportes.resolve("reporte_errores.txt"), errores);
        return errores.size();
    }

    /**
     * Lee el archivo de productos ({@code ID;Nombre;Precio}).
     *
     * @param ruta    ruta del archivo
     * @param errores lista donde se registran los problemas encontrados
     * @return mapa id de producto - informacion del producto
     * @throws IOException si el archivo no se puede leer
     */
    private static Map<String, InfoProducto> cargarProductos(Path ruta, List<String> errores)
            throws IOException {
        Map<String, InfoProducto> productos = new LinkedHashMap<String, InfoProducto>();
        List<String> lineas = leerLineas(ruta);
        for (int i = 0; i < lineas.size(); i++) {
            String linea = lineas.get(i).trim();
            if (linea.isEmpty() || esEncabezado(linea, "idproducto")) {
                continue;
            }
            String origen = ARCHIVO_PRODUCTOS + " linea " + (i + 1);
            String[] campos = linea.split(SEPARADOR, -1);
            if (campos.length < 3 || campos[0].trim().isEmpty() || campos[1].trim().isEmpty()) {
                errores.add(origen + ": formato erroneo -> " + linea);
                continue;
            }
            BigDecimal precio;
            try {
                precio = new BigDecimal(campos[2].trim());
            } catch (NumberFormatException e) {
                errores.add(origen + ": precio no numerico -> " + linea);
                continue;
            }
            if (precio.signum() < 0) {
                errores.add(origen + ": precio negativo -> " + linea);
                continue;
            }
            String id = campos[0].trim();
            if (productos.containsKey(id)) {
                errores.add(origen + ": id de producto repetido -> " + id);
                continue;
            }
            productos.put(id, new InfoProducto(id, campos[1].trim(), precio));
        }
        return productos;
    }

    /**
     * Lee el archivo de vendedores ({@code Tipo;Numero;Nombres;Apellidos}).
     *
     * @param ruta    ruta del archivo
     * @param errores lista donde se registran los problemas encontrados
     * @return mapa "tipo;numero" - informacion del vendedor
     * @throws IOException si el archivo no se puede leer
     */
    private static Map<String, InfoVendedor> cargarVendedores(Path ruta, List<String> errores)
            throws IOException {
        Map<String, InfoVendedor> vendedores = new LinkedHashMap<String, InfoVendedor>();
        List<String> lineas = leerLineas(ruta);
        for (int i = 0; i < lineas.size(); i++) {
            String linea = lineas.get(i).trim();
            if (linea.isEmpty() || esEncabezado(linea, "tipodocumento")) {
                continue;
            }
            String origen = ARCHIVO_VENDEDORES + " linea " + (i + 1);
            String[] campos = linea.split(SEPARADOR, -1);
            if (campos.length < 4 || campos[0].trim().isEmpty() || campos[1].trim().isEmpty()) {
                errores.add(origen + ": formato erroneo -> " + linea);
                continue;
            }
            String clave = campos[0].trim() + SEPARADOR + campos[1].trim();
            if (vendedores.containsKey(clave)) {
                errores.add(origen + ": vendedor repetido -> " + clave);
                continue;
            }
            String nombre = (campos[2].trim() + " " + campos[3].trim()).trim();
            vendedores.put(clave, new InfoVendedor(nombre));
        }
        return vendedores;
    }

    /**
     * Recorre la carpeta de datos y procesa cada archivo de ventas. Como se
     * acumula por documento del encabezado, varios archivos del mismo vendedor
     * se suman correctamente.
     *
     * @return cantidad de archivos de ventas encontrados
     */
    private static int procesarVentas(Path carpetaDatos, Map<String, InfoProducto> productos,
            Map<String, InfoVendedor> vendedores, List<String> errores) throws IOException {
        List<Path> archivos = new ArrayList<Path>();
        try (DirectoryStream<Path> flujo = Files.newDirectoryStream(carpetaDatos,
                PREFIJO_VENTAS + "*.txt")) {
            for (Path archivo : flujo) {
                archivos.add(archivo);
            }
        }
        Collections.sort(archivos);
        for (Path archivo : archivos) {
            procesarArchivoVentas(archivo, productos, vendedores, errores);
        }
        return archivos.size();
    }

    /**
     * Procesa un archivo de ventas: valida el encabezado y cada linea de venta
     * y acumula dinero por vendedor y cantidad por producto.
     */
    private static void procesarArchivoVentas(Path archivo, Map<String, InfoProducto> productos,
            Map<String, InfoVendedor> vendedores, List<String> errores) throws IOException {
        String nombreArchivo = archivo.getFileName().toString();
        List<String> lineas = leerLineas(archivo);

        int indiceEncabezado = 0;
        while (indiceEncabezado < lineas.size() && lineas.get(indiceEncabezado).trim().isEmpty()) {
            indiceEncabezado++;
        }
        if (indiceEncabezado == lineas.size()) {
            errores.add(nombreArchivo + ": archivo vacio");
            return;
        }
        String[] encabezado = lineas.get(indiceEncabezado).trim().split(SEPARADOR, -1);
        if (encabezado.length < 2 || encabezado[0].trim().isEmpty()
                || encabezado[1].trim().isEmpty()) {
            errores.add(nombreArchivo + ": encabezado erroneo, se descarta el archivo -> "
                    + lineas.get(indiceEncabezado));
            return;
        }
        String clave = encabezado[0].trim() + SEPARADOR + encabezado[1].trim();
        InfoVendedor vendedor = vendedores.get(clave);
        if (vendedor == null) {
            errores.add(nombreArchivo + ": el vendedor " + clave
                    + " no existe en " + ARCHIVO_VENDEDORES + ", se descarta el archivo");
            return;
        }

        for (int i = indiceEncabezado + 1; i < lineas.size(); i++) {
            String linea = lineas.get(i).trim();
            if (linea.isEmpty()) {
                continue;
            }
            String origen = nombreArchivo + " linea " + (i + 1);
            String[] campos = linea.split(SEPARADOR, -1);
            if (campos.length < 2 || campos[0].trim().isEmpty()) {
                errores.add(origen + ": formato erroneo -> " + linea);
                continue;
            }
            InfoProducto producto = productos.get(campos[0].trim());
            if (producto == null) {
                errores.add(origen + ": el producto " + campos[0].trim() + " no existe");
                continue;
            }
            long cantidad;
            try {
                cantidad = Long.parseLong(campos[1].trim());
            } catch (NumberFormatException e) {
                errores.add(origen + ": cantidad no valida -> " + linea);
                continue;
            }
            if (cantidad < 0) {
                errores.add(origen + ": cantidad negativa -> " + linea);
                continue;
            }
            producto.cantidadVendida += cantidad;
            vendedor.totalRecaudado = vendedor.totalRecaudado
                    .add(producto.precioPorUnidad.multiply(BigDecimal.valueOf(cantidad)));
        }
    }

    /**
     * Escribe el reporte de vendedores ordenado de mayor a menor recaudo.
     */
    private static void escribirReporteVendedores(Path ruta, Map<String, InfoVendedor> vendedores)
            throws IOException {
        List<InfoVendedor> lista = new ArrayList<InfoVendedor>(vendedores.values());
        Collections.sort(lista, (a, b) -> {
            int comparacion = b.totalRecaudado.compareTo(a.totalRecaudado);
            return comparacion != 0 ? comparacion : a.nombreCompleto.compareTo(b.nombreCompleto);
        });
        List<String> salida = new ArrayList<String>();
        for (InfoVendedor vendedor : lista) {
            salida.add(vendedor.nombreCompleto + SEPARADOR
                    + vendedor.totalRecaudado.setScale(2, RoundingMode.HALF_UP).toPlainString());
        }
        Files.write(ruta, salida, StandardCharsets.UTF_8);
    }

    /**
     * Escribe el reporte de productos vendidos ordenado de mayor a menor
     * cantidad vendida (solo productos con al menos una unidad vendida).
     */
    private static void escribirReporteProductos(Path ruta, Map<String, InfoProducto> productos)
            throws IOException {
        List<InfoProducto> lista = new ArrayList<InfoProducto>();
        for (InfoProducto producto : productos.values()) {
            if (producto.cantidadVendida > 0) {
                lista.add(producto);
            }
        }
        Collections.sort(lista, (a, b) -> {
            int comparacion = Long.compare(b.cantidadVendida, a.cantidadVendida);
            return comparacion != 0 ? comparacion : a.nombre.compareTo(b.nombre);
        });
        List<String> salida = new ArrayList<String>();
        for (InfoProducto producto : lista) {
            salida.add(producto.nombre + SEPARADOR + producto.precioPorUnidad.toPlainString());
        }
        Files.write(ruta, salida, StandardCharsets.UTF_8);
    }

    /**
     * Escribe el detalle de los registros descartados.
     */
    private static void escribirErrores(Path ruta, List<String> errores) throws IOException {
        List<String> salida = new ArrayList<String>();
        if (errores.isEmpty()) {
            salida.add("Sin errores: todos los archivos tenian formato e informacion validos.");
        } else {
            salida.addAll(errores);
        }
        Files.write(ruta, salida, StandardCharsets.UTF_8);
    }

    /**
     * Lee todas las lineas de un archivo en UTF-8, eliminando el BOM si existe.
     *
     * @throws IOException si el archivo no existe o no se puede leer
     */
    private static List<String> leerLineas(Path ruta) throws IOException {
        if (!Files.isRegularFile(ruta)) {
            throw new IOException("No se encontro el archivo requerido: " + ruta);
        }
        List<String> lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);
        if (!lineas.isEmpty() && lineas.get(0).startsWith("\uFEFF")) {
            lineas.set(0, lineas.get(0).substring(1));
        }
        return lineas;
    }

    /**
     * Indica si una linea es un encabezado de columnas (por si el archivo lo trae).
     */
    private static boolean esEncabezado(String linea, String prefijo) {
        return linea.toLowerCase().startsWith(prefijo);
    }
}
